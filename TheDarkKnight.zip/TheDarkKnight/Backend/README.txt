Commands to run:
npx hardhat clean && npx hardhat node
npx hardhat run ./scripts/deploy.js --network localhost
npx hardhat run ./scripts/deployWithData.js --network localhost

Localhost data:
RPC: http://127.0.0.1:8545/
Chain ID: 1337