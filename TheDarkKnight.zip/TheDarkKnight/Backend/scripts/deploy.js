const hre = require('hardhat');
async function main() {
    const ETHICS_REQUIREMENTS = [
        "Task or submission does not produce content of excessive harm of living beings.",
        "Task or submission does not produce content of weapons of which the prominent purpose is to harm.",
        "Task or submission does not produce content of any non-consentual nudity or sexual acts.",
        "Task or submission does not produce content of an individual's information for which there is a reasonable expectation of privacy."
    ];
    const UsersContractFactory = await hre.ethers.getContractFactory("Users");
    const usersContract = await UsersContractFactory.deploy();
    const usersAddress = usersContract.target;
    const TheListContractFactory = await hre.ethers.getContractFactory("TheList");
    const theListContract = await TheListContractFactory.deploy(ETHICS_REQUIREMENTS, usersAddress);
    const HashTaskContractFactory = await hre.ethers.getContractFactory("HashTask");
    const hashTaskContract = await HashTaskContractFactory.deploy(usersAddress);
    const DoubleHashTaskFactory = await hre.ethers.getContractFactory("DoubleHashTask");
    const doubleHashTaskContract = await DoubleHashTaskFactory.deploy(usersAddress);
    const ValidatorTaskFactory = await hre.ethers.getContractFactory("ValidatorTask");
    const validatorTaskContract = await ValidatorTaskFactory.deploy(usersAddress);
}
main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });